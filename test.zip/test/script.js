let button = document.querySelector('#send');
button.addEventListener('click', myfunc);
let val = {}, jsons = [];
let url = '';
let xhr = new XMLHttpRequest();

function myfunc() {
    for (let i = 0; i < 2; i++) {
        let values = document.querySelectorAll('.form')[i].elements['a'].value;
        val = { id: i + 1, value: values }
        jsons.push(val)

    }




    console.log(jsons);
}